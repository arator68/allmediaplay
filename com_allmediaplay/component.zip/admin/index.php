<?php
 echo "AllMediaPlay";
 ?>