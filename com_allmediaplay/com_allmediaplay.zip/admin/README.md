allmediaplay
============

AllMediaPlay for Joomla
