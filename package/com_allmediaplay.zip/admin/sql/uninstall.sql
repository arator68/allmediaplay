-- $Id: uninstall.sql 892 2008-05-26 13:37:35Z Fritz Elfert $
--

DROP TABLE IF EXISTS `#__allmediaplay_player`;
DROP TABLE IF EXISTS `#__allmediaplay_ripper`;
DROP TABLE IF EXISTS `#__allmediaplay_tags`;
DROP TABLE IF EXISTS `#__allmediaplay_popup`;
